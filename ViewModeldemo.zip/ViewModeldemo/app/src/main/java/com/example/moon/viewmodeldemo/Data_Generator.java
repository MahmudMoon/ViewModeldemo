package com.example.moon.viewmodeldemo;

import java.util.Random;

public class Data_Generator {
    int number=-1;
    public int getNumber(){
        if(number==-1) {
            Random random = new Random();
            number = random.nextInt(10);
        }
        return number;
    }
}
